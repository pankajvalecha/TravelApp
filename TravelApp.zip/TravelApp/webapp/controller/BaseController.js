sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel",
		"sap/m/MessageToast",
		"sap/m/MessageBox",
		'sap/ui/core/Fragment',
	],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function(Controller, JSONModel, MessageToast, MessageBox, Fragment) {
		"use strict";

		return Controller.extend("com.poc.ui5_TravelApp.controller.BaseController", {

			onFRSelect: function(oEvent) {
				var nOption = oEvent.getParameters().selectedIndex;
				var oTable = this.getView().byId("idForeignRefTable");
				oTable.setVisible(nOption ? false : true);
			},

			onCountriesAddPress: function() {
				if (!this._oCountryDialog) {
					this._oCountryDialog = sap.ui.xmlfragment("com.poc.ui5_TravelApp.view.fragments.CountryRecord", this);
					this.getView().addDependent(this._oCountryDialog);
				}
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oCountryDialog);
				this._oCountryDialog.open();
			},

			onFRAddPress: function() {
				if (!this._oForeignRefDialog) {
					this._oForeignRefDialog = sap.ui.xmlfragment("com.poc.ui5_TravelApp.view.fragments.ForeignReference", this);
					this.getView().addDependent(this._oForeignRefDialog);
				}
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oForeignRefDialog);
				this._oForeignRefDialog.open();
			},

			onTransportAddPress: function() {
				if (!this._oTransportDialog) {
					this._oTransportDialog = sap.ui.xmlfragment("com.poc.ui5_TravelApp.view.fragments.TransportModeRecord", this);
					this.getView().addDependent(this._oTransportDialog);
				}
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oTransportDialog);
				this._oTransportDialog.open();
			},

			onAccomodationAddPress: function() {
				if (!this._oAccomodationDialog) {
					this._oAccomodationDialog = sap.ui.xmlfragment("com.poc.ui5_TravelApp.view.fragments.AccomodationRecord", this);
					this.getView().addDependent(this._oAccomodationDialog);
				}
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAccomodationDialog);
				this._oAccomodationDialog.open();
			},

			onEditSingleCountry: function(oEvent) {
				//oEvent.getSource().getBindingContext("UserV2Model").getObject();
				this.onCountriesAddPress();
			},

			onEditSingleForeignRef: function(oEvent) {
				this.onFRAddPress();
			},

			onEditSingleAccomodation: function(oEvent) {
				this.onAccomodationAddPress();
			},

			onEditSingleTransport: function(oEvent) {
				this.onTransportAddPress();
			},

			onCountryClose: function(oEvent) {
				if (this._oCountryDialog) {
					this._oCountryDialog.close();
					this._oCountryDialog.destroy();
					delete this._oCountryDialog;
				}
			},

			onForeignRefClose: function(oEvent) {
				if (this._oForeignRefDialog) {
					this._oForeignRefDialog.close();
					this._oForeignRefDialog.destroy();
					delete this._oForeignRefDialog;
				}
			},

			onTransportRecordClose: function() {
				if (this._oTransportDialog) {
					this._oTransportDialog.close();
					this._oTransportDialog.destroy();
					delete this._oTransportDialog;
				}
			},

			onAccomodationClose: function() {
				if (this._oAccomodationDialog) {
					this._oAccomodationDialog.close();
					this._oAccomodationDialog.destroy();
					delete this._oAccomodationDialog;
				}
			},

			onEmployeeHelpPress: function() {
				var oView = this.getView();

				if (!this._pValueHelpDialog) {
					this._pValueHelpDialog = Fragment.load({
						id: oView.getId(),
						name: "com.poc.ui5_TravelApp.view.fragments.EmployeeF4Help",
						controller: this
					}).then(function(oValueHelpDialog) {
						oView.addDependent(oValueHelpDialog);
						return oValueHelpDialog;
					});
				}
				this._pValueHelpDialog.then(function(oValueHelpDialog) {
					jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), oValueHelpDialog);
					oValueHelpDialog.open();
				}.bind(this));
			}

		});
	});