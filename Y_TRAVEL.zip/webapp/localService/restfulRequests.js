sap.ui.define([], function () {
	return [
		{
			method: "POST",
			path: new RegExp('/?'),
			response: function (oXhr, sUrlParams) {
				oXhr.respondJSON(200, {}, JSON.stringify(
					{
						
					}
				));
			}
		}
	];
});