sap.ui.define([
		"sap/ui/core/mvc/Controller",
		"sap/ui/model/json/JSONModel",
		"sap/m/MessageToast",
		"sap/m/MessageBox",
		'sap/ui/core/Fragment',
	],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function(Controller, JSONModel, MessageToast, MessageBox, Fragment) {
		"use strict";

		return Controller.extend("com.poc.ui5_TravelApp.controller.BaseController", {
			
			getResourceBundle: function () {
                var oBundle = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                return oBundle;
            },


			getText: function (textName) {
				var args = Array.prototype.slice.call(arguments);
				var sText = args.shift();
				if (Array.isArray(args[0])) {
					args = args[0];
				}
				return this.getResourceBundle().getText(sText, args);
			},
    
            /**
             * Convenience method for accessing the router in each controller of the application.
             * @public
             * @returns {sap.ui.core.routing.Router} the router for this component
             */
            getRouter: function () {
                return this.getOwnerComponent().getRouter();
            },
            /**
             * Convenience method for getting the view model by name in every controller of the application.
             * @public
             * @param {string} sName the model name
             * @returns {sap.ui.model.Model} the model instance
             */
            getModel: function (sName) {
                return this.getView().getModel(sName) || this.getOwnerComponent().getModel(sName);
            },


			onFRSelect: function(oEvent) {
				var nOption = oEvent.getParameters().selectedIndex;
				var oTable = this.getView().byId("idForeignRefTable");
				oTable.setVisible(nOption ? false : true);
			},

			onCountriesAddPress: function() {
				if (!this._oCountryDialog) {
					this._oCountryDialog = sap.ui.xmlfragment("com.poc.ui5_TravelApp.view.fragments.CountryRecord", this);
					this.getView().addDependent(this._oCountryDialog);
				}
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oCountryDialog);
				this._oCountryDialog.open();
			},

			onFRAddPress: function() {
				if (!this._oForeignRefDialog) {
					this._oForeignRefDialog = sap.ui.xmlfragment("com.poc.ui5_TravelApp.view.fragments.ForeignReference", this);
					this.getView().addDependent(this._oForeignRefDialog);
				}
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oForeignRefDialog);
				this._oForeignRefDialog.open();
			},

			onTransportAddPress: function() {
				if (!this._oTransportDialog) {
					this._oTransportDialog = sap.ui.xmlfragment("com.poc.ui5_TravelApp.view.fragments.TransportModeRecord", this);
					this.getView().addDependent(this._oTransportDialog);
				}
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oTransportDialog);
				this._oTransportDialog.open();
			},

			onAccomodationAddPress: function() {
				if (!this._oAccomodationDialog) {
					this._oAccomodationDialog = sap.ui.xmlfragment("com.poc.ui5_TravelApp.view.fragments.AccomodationRecord", this);
					this.getView().addDependent(this._oAccomodationDialog);
				}
				jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), this._oAccomodationDialog);
				this._oAccomodationDialog.open();
			},

			onEditSingleCountry: function(oEvent) {
				//oEvent.getSource().getBindingContext("UserV2Model").getObject();
				this.onCountriesAddPress();
			},

			onEditSingleForeignRef: function(oEvent) {
				this.onFRAddPress();
			},

			onEditSingleAccomodation: function(oEvent) {
				this.onAccomodationAddPress();
			},

			onEditSingleTransport: function(oEvent) {
				this.onTransportAddPress();
			},

			onCountryClose: function(oEvent) {
				if (this._oCountryDialog) {
					this._oCountryDialog.close();
					this._oCountryDialog.destroy();
					delete this._oCountryDialog;
				}
			},

			onForeignRefClose: function(oEvent) {
				if (this._oForeignRefDialog) {
					this._oForeignRefDialog.close();
					this._oForeignRefDialog.destroy();
					delete this._oForeignRefDialog;
				}
			},

			onTransportRecordClose: function() {
				if (this._oTransportDialog) {
					this._oTransportDialog.close();
					this._oTransportDialog.destroy();
					delete this._oTransportDialog;
				}
			},

			onAccomodationClose: function() {
				if (this._oAccomodationDialog) {
					this._oAccomodationDialog.close();
					this._oAccomodationDialog.destroy();
					delete this._oAccomodationDialog;
				}
			},

			onEmployeeHelpPress: function() {
				var oView = this.getView();

				if (!this._pValueHelpDialog) {
					this._pValueHelpDialog = Fragment.load({
						id: oView.getId(),
						name: "com.poc.ui5_TravelApp.view.fragments.EmployeeF4Help",
						controller: this
					}).then(function(oValueHelpDialog) {
						oView.addDependent(oValueHelpDialog);
						return oValueHelpDialog;
					});
				}
				this._pValueHelpDialog.then(function(oValueHelpDialog) {
					jQuery.sap.syncStyleClass(this.getOwnerComponent().getContentDensityClass(), this.getView(), oValueHelpDialog);
					oValueHelpDialog.open();
				}.bind(this));
			},
			
			onOtherReasonSelect: function(oEvent){
				var bSelect = oEvent.getParameter("selected");
				var oInputOther = this.getView().byId("idChkOtherReason");
				var sValue = oInputOther.getValue();
				oInputOther.setEditable(bSelect);
				oInputOther.setValue(bSelect ? sValue : "");
			},
			
			onOtherDependentSelect: function(oEvent){
				var nIndex = oEvent.getParameter("selectedIndex");
				var oInputOther = this.getView().byId("idOtherDependents");
				var sValue = oInputOther.getValue();
				oInputOther.setEditable(nIndex === 0);
				oInputOther.setValue(nIndex === 0 ? sValue : "");
			}
		});
	});