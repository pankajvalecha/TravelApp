sap.ui.define([
	"com/poc/ui5_TravelApp/controller/BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("com.poc.ui5_TravelApp.controller.App", {

	});
});