sap.ui.define([
	"com/poc/ui5_TravelApp/controller/BaseController",
	"sap/ui/model/json/JSONModel"
], function(BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("com.poc.ui5_TravelApp.controller.EditForeignTravel", {

		/**
		 * Called when a controller is instantiated and its View controls (if available) are already created.
		 * Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		 * @memberOf com.poc.ui5_TravelApp.view.EditForeignTravel
		 */
		onInit: function() {
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			this._oRouter = this.getRouter();
			this._oRouter.attachRouteMatched(this.onEditRouteMatched, this);
		},

		/**
		 * Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		 * (NOT before the first rendering! onInit() is used for that one!).
		 * @memberOf com.poc.ui5_TravelApp.view.EditForeignTravel
		 */
		//	onBeforeRendering: function() {
		//
		//	},

		/**
		 * Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		 * This hook is the same one that SAPUI5 controls get after being rendered.
		 * @memberOf com.poc.ui5_TravelApp.view.EditForeignTravel
		 */
		//	onAfterRendering: function() {
		//
		//	},

		/**
		 * Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		 * @memberOf com.poc.ui5_TravelApp.view.EditForeignTravel
		 */
		//	onExit: function() {
		//
		//	}

		onEditRouteMatched: function(oEvent) {
			var oView = this.getView();
			var oModel = this.getModel("Core");
			var oOtherChk = oView.byId("idChkOther");
			var oMoreDependents = oView.byId("idRBGDependents");
			if (oEvent && oEvent.getParameter("name") === "EditForeignTravel") {
				this._params = oEvent.getParameter("arguments");
				oView.setBusy(true);
				oModel.read("/" + this._params.path, {
					urlParameters: {
						"$expand": "to_ForeignNationals,to_TravelCountries,to_TravelCountries/to_Accommodation,to_TravelCountries/to_TransportMode"
					},
					success: function(oData) {
						oView.setModel(new JSONModel(oData), "Record");
						oOtherChk.fireSelect({
							selected: oData.Isother === 'Y'
						});
						oMoreDependents.fireSelect({
							selectedIndex: oData.Withdependents === 'Y' ? 0 : 1
						});
						oView.setBusy(false);
					},
					error: function(oError) {
						oView.setBusy(false);
					}
				});
			}
		}
	});

});